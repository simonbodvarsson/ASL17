#!/bin/bash
# chmod +x 61_experiments.sh
# ./61_experiments.sh

v=32 #VC
Server_num='2 3'
Middleware_num='1 2'
Worker_values='8 32'

repeat_num=3  # At least 3
exp_length=75 #(Needs to be 80s?)
sleep_length=$((exp_length + 15))

# 3 load generator VM (with 2 instances of memtier)
# 1 AND 2 middlewares
# 2 AND 3 memcached server
# 8 AND 32 worker threads
echo "========== Experiment 6.1: 2K Analysis ==========" 

# Start and populate one server
echo Populating server...
ssh server1 'screen -S memc -d -m bash -c "memcached -p 11212 -vv"'
ssh server1 './memtier_benchmark-master/memtier_benchmark -d 1024 -n 10001 --key-pattern=S:S -p 11212 --ratio 1:0 --clients=1 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --hide-histogram'

ssh server2 'screen -S memc -d -m bash -c "memcached -p 11212 -vv"'
ssh server2 './memtier_benchmark-master/memtier_benchmark -d 1024 -n 10001 --key-pattern=S:S -p 11212 --ratio 1:0 --clients=1 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --hide-histogram'

ssh server3 'screen -S memc -d -m bash -c "memcached -p 11212 -vv"'
ssh server3 './memtier_benchmark-master/memtier_benchmark -d 1024 -n 10001 --key-pattern=S:S -p 11212 --ratio 1:0 --clients=1 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --hide-histogram'


ssh middleware1 "ping 10.0.0.5 -c 4 |& tee mw_1_pings.log"
ssh middleware1 "ping 10.0.0.7 -c 4 |& tee -a mw_1_pings.log"
ssh middleware1 "ping 10.0.0.11 -c 4 |& tee -a mw_1_pings.log"

ssh middleware2 "ping 10.0.0.5 -c 4 |& tee mw_2_pings.log"
ssh middleware2 "ping 10.0.0.7 -c 4 |& tee -a mw_2_pings.log"
ssh middleware2 "ping 10.0.0.11 -c 4 |& tee -a mw_2_pings.log"

scp middleware1:mw_1_pings.log ./logs/mw1_pings.log
scp middleware2:mw_2_pings.log ./logs/mw2_pings.log

ssh middleware1 rm mw_1_pings.log
ssh middleware2 rm mw_2_pings.log

# Iterate through experiment configurations
echo "Running Experiments..."
echo "GETS"
for servers in $Server_num; do
	for middlewares in $Middleware_num; do
		for threads in $Worker_values; do
			path="./logs/GETS/servers_$servers/mws_$middlewares/wt_$threads/"
			echo $path
			echo "Servers: $servers Middlewares: $middlewares Threads: $threads"
			
			for ((rep=1;rep<=repeat_num;rep++)); do
				
				# Start MWs
				if [[ servers -eq 2 ]]; then
					echo Two servers
					# Start first MW
					ssh middleware1 "screen -S mw1 -d -m bash -c 'java -cp ./asl-fall17-project/build/ RunMW -l 10.0.0.8 -p 6379 -t $threads -s false -m 10.0.0.5:11212 10.0.0.7:11212|& tee -a mw1_get.log'"
					
					if [[ middlewares -eq 2 ]]; then
						# Start second MW
						ssh middleware2 "screen -S mw2 -d -m bash -c 'java -cp ./asl-fall17-project/build/ RunMW -l 10.0.0.9 -p 6379 -t $threads -s false -m 10.0.0.5:11212 10.0.0.7:11212 |& tee -a mw2_get.log'"
					fi	
				fi


				if [[ servers -eq 3 ]]; then
					echo Three servers
					# Start first MW
					ssh middleware1 "screen -S mw1 -d -m bash -c 'java -cp ./asl-fall17-project/build/ RunMW -l 10.0.0.8 -p 6379 -t $threads -s false -m 10.0.0.5:11212 10.0.0.7:11212 10.0.0.11:11212 |& tee -a mw1_get.log'" 
					
					if [[ middlewares -eq 2 ]]; then
						# Start second MW
						ssh middleware2 "screen -S mw2 -d -m bash -c 'java -cp ./asl-fall17-project/build/ RunMW -l 10.0.0.9 -p 6379 -t $threads -s false -m 10.0.0.5:11212 10.0.0.7:11212 10.0.0.11:11212 |& tee -a mw2_get.log'"
					fi	
				fi


				# Start Clients
				if [[ middlewares -eq 1 ]]; then
					ssh client1 "screen -S client1 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 0:1 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client1_get_rep$rep.json |& tee -a client1_get.log'"
					ssh client1 "screen -S client2 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 0:1 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client2_get_rep$rep.json |& tee -a client2_get.log'"
					ssh client2 "screen -S client1 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 0:1 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client1_get_rep$rep.json |& tee -a client1_get.log'"
					ssh client2 "screen -S client2 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 0:1 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client2_get_rep$rep.json |& tee -a client2_get.log'"
					ssh client3 "screen -S client1 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 0:1 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client1_get_rep$rep.json |& tee -a client1_get.log'"
					ssh client3 "screen -S client2 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 0:1 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client2_get_rep$rep.json |& tee -a client2_get.log'"
				fi

				if [[ middlewares -eq 2 ]]; then
					ssh client1 "screen -S client1 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 0:1 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client1_get_rep$rep.json |& tee -a client1_get.log'"
					ssh client1 "screen -S client2 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.9 --test-time=$exp_length --ratio 0:1 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client2_get_rep$rep.json |& tee -a client2_get.log'"
					ssh client2 "screen -S client1 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 0:1 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client1_get_rep$rep.json |& tee -a client1_get.log'"
					ssh client2 "screen -S client2 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.9 --test-time=$exp_length --ratio 0:1 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client2_get_rep$rep.json |& tee -a client2_get.log'"
					ssh client3 "screen -S client1 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 0:1 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client1_get_rep$rep.json |& tee -a client1_get.log'"
					ssh client3 "screen -S client2 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.9 --test-time=$exp_length --ratio 0:1 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client2_get_rep$rep.json |& tee -a client2_get.log'"
				fi

				# Wait for experiment to finish
				sleep $sleep_length

				# Kill clients
				ssh client1 screen "-S client1 -X quit"
				ssh client1 screen "-S client2 -X quit"
				ssh client2 screen "-S client1 -X quit"
				ssh client2 screen "-S client2 -X quit"
				ssh client3 screen "-S client1 -X quit"
				ssh client3 screen "-S client2 -X quit"
				
				# Kill middleware
				ssh middleware1 screen '-S mw1 -X stuff ^C'
				ssh middleware2 screen '-S mw2 -X stuff ^C'
				sleep 2

				# Get JSON Logs
				scp client1:client1_get_rep$rep.json ${path}client1_inst1_rep$rep.json
				scp client1:client2_get_rep$rep.json ${path}client1_inst2_rep$rep.json
				scp client2:client1_get_rep$rep.json ${path}client2_inst1_rep$rep.json
				scp client2:client2_get_rep$rep.json ${path}client2_inst2_rep$rep.json
				scp client3:client1_get_rep$rep.json ${path}client3_inst1_rep$rep.json
				scp client3:client2_get_rep$rep.json ${path}client3_inst2_rep$rep.json
				# Delete JSON Logs
				ssh client1 rm client1_get_rep$rep.json
				ssh client1 rm client2_get_rep$rep.json
				ssh client2 rm client1_get_rep$rep.json
				ssh client2 rm client2_get_rep$rep.json
				ssh client3 rm client1_get_rep$rep.json
				ssh client3 rm client2_get_rep$rep.json
			done

			# Get Client Logs
			scp client1:client1_get.log ${path}client1_inst1.log
			scp client1:client2_get.log ${path}client1_inst2.log
			scp client2:client1_get.log ${path}client2_inst1.log
			scp client2:client2_get.log ${path}client2_inst2.log
			scp client3:client1_get.log ${path}client3_inst1.log
			scp client3:client2_get.log ${path}client3_inst2.log
			# Delete Client Logs
			ssh client1 rm client1_get.log
			ssh client1 rm client2_get.log
			ssh client2 rm client1_get.log
			ssh client2 rm client2_get.log

			# Get and Delete Middleware Logs
			scp middleware1:mw1_get.log ${path}mw1.log
			scp -r middleware1:./Experiments/. ${path}MW1/
			ssh middleware1 rm mw1_get.log
			ssh middleware1 rm -r ./Experiments
			if [[ middlewares -eq 2 ]]; then
				scp middleware2:mw2_get.log ${path}mw2.log
				scp -r middleware2:./Experiments/. ${path}MW2/
				ssh middleware2 rm mw2_get.log
				ssh middleware2 rm -r ./Experiments
			fi
		done
	done
done

echo "SETS"
for servers in $Server_num; do
	for middlewares in $Middleware_num; do
		for threads in $Worker_values; do
			path="./logs/SETS/servers_$servers/mws_$middlewares/wt_$threads/"
			echo $path
			echo "Servers: $servers Middlewares: $middlewares Threads: $threads"
			
			for ((rep=1;rep<=repeat_num;rep++)); do
				
				# Start MWs
				if [[ servers -eq 2 ]]; then
					# Start first MW
					ssh middleware1 "screen -S mw1 -d -m bash -c 'java -cp ./asl-fall17-project/build/ RunMW -l 10.0.0.8 -p 6379 -t $threads -s false -m 10.0.0.5:11212 10.0.0.7:11212 |& tee -a mw1_get.log'"
					
					if [[ middlewares -eq 2 ]]; then
						# Start second MW
						ssh middleware2 "screen -S mw2 -d -m bash -c 'java -cp ./asl-fall17-project/build/ RunMW -l 10.0.0.9 -p 6379 -t $threads -s false -m 10.0.0.5:11212 10.0.0.7:11212 |& tee -a mw2_get.log'"
					fi	
				fi


				if [[ servers -eq 3 ]]; then
					# Start first MW
					ssh middleware1 "screen -S mw1 -d -m bash -c 'java -cp ./asl-fall17-project/build/ RunMW -l 10.0.0.8 -p 6379 -t $threads -s false -m 10.0.0.5:11212 10.0.0.7:11212 10.0.0.11:11212 |& tee -a mw1_get.log'" 
					
					if [[ middlewares -eq 2 ]]; then
						# Start second MW
						ssh middleware2 "screen -S mw2 -d -m bash -c 'java -cp ./asl-fall17-project/build/ RunMW -l 10.0.0.9 -p 6379 -t $threads -s false -m 10.0.0.5:11212 10.0.0.7:11212 10.0.0.11:11212 |& tee -a mw2_get.log'"
					fi	
				fi


				# Start Clients
				if [[ middlewares -eq 1 ]]; then
					ssh client1 "screen -S client1 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 1:0 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client1_get_rep$rep.json |& tee -a client1_get.log'"
					ssh client1 "screen -S client2 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 1:0 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client2_get_rep$rep.json |& tee -a client2_get.log'"
					ssh client2 "screen -S client1 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 1:0 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client1_get_rep$rep.json |& tee -a client1_get.log'"
					ssh client2 "screen -S client2 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 1:0 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client2_get_rep$rep.json |& tee -a client2_get.log'"
					ssh client3 "screen -S client1 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 1:0 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client1_get_rep$rep.json |& tee -a client1_get.log'"
					ssh client3 "screen -S client2 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 1:0 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client2_get_rep$rep.json |& tee -a client2_get.log'"
				fi

				if [[ middlewares -eq 2 ]]; then
					ssh client1 "screen -S client1 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 1:0 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client1_get_rep$rep.json |& tee -a client1_get.log'"
					ssh client1 "screen -S client2 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.9 --test-time=$exp_length --ratio 1:0 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client2_get_rep$rep.json |& tee -a client2_get.log'"
					ssh client2 "screen -S client1 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 1:0 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client1_get_rep$rep.json |& tee -a client1_get.log'"
					ssh client2 "screen -S client2 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.9 --test-time=$exp_length --ratio 1:0 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client2_get_rep$rep.json |& tee -a client2_get.log'"
					ssh client3 "screen -S client1 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 1:0 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client1_get_rep$rep.json |& tee -a client1_get.log'"
					ssh client3 "screen -S client2 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.9 --test-time=$exp_length --ratio 1:0 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client2_get_rep$rep.json |& tee -a client2_get.log'"
				fi

				# Wait for experiment to finish
				sleep $sleep_length

				# Kill middleware
				ssh middleware1 screen '-S mw1 -X stuff ^C'
				ssh middleware2 screen '-S mw2 -X stuff ^C'
				sleep 2

				# Get JSON Logs
				scp client1:client1_get_rep$rep.json ${path}client1_inst1_rep$rep.json
				scp client1:client2_get_rep$rep.json ${path}client1_inst2_rep$rep.json
				scp client2:client1_get_rep$rep.json ${path}client2_inst1_rep$rep.json
				scp client2:client2_get_rep$rep.json ${path}client2_inst2_rep$rep.json
				scp client3:client1_get_rep$rep.json ${path}client3_inst1_rep$rep.json
				scp client3:client2_get_rep$rep.json ${path}client3_inst2_rep$rep.json
				# Delete JSON Logs
				ssh client1 rm client1_get_rep$rep.json
				ssh client1 rm client2_get_rep$rep.json
				ssh client2 rm client1_get_rep$rep.json
				ssh client2 rm client2_get_rep$rep.json
				ssh client3 rm client1_get_rep$rep.json
				ssh client3 rm client2_get_rep$rep.json
			done

			# Get Client Logs
			scp client1:client1_get.log ${path}client1_inst1.log
			scp client1:client2_get.log ${path}client1_inst2.log
			scp client2:client1_get.log ${path}client2_inst1.log
			scp client2:client2_get.log ${path}client2_inst2.log
			scp client3:client1_get.log ${path}client3_inst1.log
			scp client3:client2_get.log ${path}client3_inst2.log
			# Delete Client Logs
			ssh client1 rm client1_get.log
			ssh client1 rm client2_get.log
			ssh client2 rm client1_get.log
			ssh client2 rm client2_get.log

			# Get and Delete Middleware Logs
			scp middleware1:mw1_get.log ${path}mw1.log
			scp -r middleware1:./Experiments/. ${path}MW1/
			ssh middleware1 rm mw1_get.log
			ssh middleware1 rm -r ./Experiments
			if [[ middlewares -eq 2 ]]; then
				scp middleware2:mw2_get.log ${path}mw2.log
				scp -r middleware2:./Experiments/. ${path}MW2/
				ssh middleware2 rm mw2_get.log
				ssh middleware2 rm -r ./Experiments
			fi
		done
	done
done


echo "50/50 GETS-SETS"
for servers in $Server_num; do
	for middlewares in $Middleware_num; do
		for threads in $Worker_values; do
			path="./logs/GETSET/servers_$servers/mws_$middlewares/wt_$threads/"
			echo $path
			echo "Servers: $servers Middlewares: $middlewares Threads: $threads"
			
			for ((rep=1;rep<=repeat_num;rep++)); do
				
				# Start MWs
				if [[ servers -eq 2 ]]; then
					# Start first MW
					ssh middleware1 "screen -S mw1 -d -m bash -c 'java -cp ./asl-fall17-project/build/ RunMW -l 10.0.0.8 -p 6379 -t $threads -s false -m 10.0.0.5:11212 10.0.0.7:11212|& tee -a mw1_get.log'"
					
					if [[ middlewares -eq 2 ]]; then
						# Start second MW
						ssh middleware2 "screen -S mw2 -d -m bash -c 'java -cp ./asl-fall17-project/build/ RunMW -l 10.0.0.9 -p 6379 -t $threads -s false -m 10.0.0.5:11212 10.0.0.7:11212 |& tee -a mw2_get.log'"
					fi	
				fi


				if [[ servers -eq 3 ]]; then
					# Start first MW
					ssh middleware1 "screen -S mw1 -d -m bash -c 'java -cp ./asl-fall17-project/build/ RunMW -l 10.0.0.8 -p 6379 -t $threads -s false -m 10.0.0.5:11212 10.0.0.7:11212 10.0.0.11:11212 |& tee -a mw1_get.log'" 
					
					if [[ middlewares -eq 2 ]]; then
						# Start second MW
						ssh middleware2 "screen -S mw2 -d -m bash -c 'java -cp ./asl-fall17-project/build/ RunMW -l 10.0.0.9 -p 6379 -t $threads -s false -m 10.0.0.5:11212 10.0.0.7:11212 10.0.0.11:11212 |& tee -a mw2_get.log'"
					fi	
				fi


				# Start Clients
				if [[ middlewares -eq 1 ]]; then
					ssh client1 "screen -S client1 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 1:1 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client1_get_rep$rep.json |& tee -a client1_get.log'"
					ssh client1 "screen -S client2 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 1:1 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client2_get_rep$rep.json |& tee -a client2_get.log'"
					ssh client2 "screen -S client1 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 1:1 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client1_get_rep$rep.json |& tee -a client1_get.log'"
					ssh client2 "screen -S client2 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 1:1 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client2_get_rep$rep.json |& tee -a client2_get.log'"
					ssh client3 "screen -S client1 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 1:1 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client1_get_rep$rep.json |& tee -a client1_get.log'"
					ssh client3 "screen -S client2 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 1:1 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client2_get_rep$rep.json |& tee -a client2_get.log'"
				fi

				if [[ middlewares -eq 2 ]]; then
					ssh client1 "screen -S client1 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 1:1 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client1_get_rep$rep.json |& tee -a client1_get.log'"
					ssh client1 "screen -S client2 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.9 --test-time=$exp_length --ratio 1:1 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client2_get_rep$rep.json |& tee -a client2_get.log'"
					ssh client2 "screen -S client1 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 1:1 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client1_get_rep$rep.json |& tee -a client1_get.log'"
					ssh client2 "screen -S client2 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.9 --test-time=$exp_length --ratio 1:1 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client2_get_rep$rep.json |& tee -a client2_get.log'"
					ssh client3 "screen -S client1 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 1:1 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client1_get_rep$rep.json |& tee -a client1_get.log'"
					ssh client3 "screen -S client2 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.9 --test-time=$exp_length --ratio 1:1 --clients=32 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client2_get_rep$rep.json |& tee -a client2_get.log'"
				fi

				# Wait for experiment to finish
				sleep $sleep_length

				# Kill middleware
				ssh middleware1 screen '-S mw1 -X stuff ^C'
				ssh middleware2 screen '-S mw2 -X stuff ^C'
				sleep 2

				# Get JSON Logs
				scp client1:client1_get_rep$rep.json ${path}client1_inst1_rep$rep.json
				scp client1:client2_get_rep$rep.json ${path}client1_inst2_rep$rep.json
				scp client2:client1_get_rep$rep.json ${path}client2_inst1_rep$rep.json
				scp client2:client2_get_rep$rep.json ${path}client2_inst2_rep$rep.json
				scp client3:client1_get_rep$rep.json ${path}client3_inst1_rep$rep.json
				scp client3:client2_get_rep$rep.json ${path}client3_inst2_rep$rep.json
				# Delete JSON Logs
				ssh client1 rm client1_get_rep$rep.json
				ssh client1 rm client2_get_rep$rep.json
				ssh client2 rm client1_get_rep$rep.json
				ssh client2 rm client2_get_rep$rep.json
				ssh client3 rm client1_get_rep$rep.json
				ssh client3 rm client2_get_rep$rep.json
			done

			# Get Client Logs
			scp client1:client1_get.log ${path}client1_inst1.log
			scp client1:client2_get.log ${path}client1_inst2.log
			scp client2:client1_get.log ${path}client2_inst1.log
			scp client2:client2_get.log ${path}client2_inst2.log
			scp client3:client1_get.log ${path}client3_inst1.log
			scp client3:client2_get.log ${path}client3_inst2.log
			# Delete Client Logs
			ssh client1 rm client1_get.log
			ssh client1 rm client2_get.log
			ssh client2 rm client1_get.log
			ssh client2 rm client2_get.log

			# Get and Delete Middleware Logs
			scp middleware1:mw1_get.log ${path}mw1.log
			scp -r middleware1:./Experiments/. ${path}MW1/
			ssh middleware1 rm mw1_get.log
			ssh middleware1 rm -r ./Experiments
			if [[ middlewares -eq 2 ]]; then
				scp middleware2:mw2_get.log ${path}mw2.log
				scp -r middleware2:./Experiments/. ${path}MW2/
				ssh middleware2 rm mw2_get.log
				ssh middleware2 rm -r ./Experiments
			fi
		done
	done
done

echo "All Experiments finished!"

# Kill servers
ssh server1 screen "-S memc -X quit"
ssh server2 screen "-S memc -X quit"
ssh server3 screen "-S memc -X quit"