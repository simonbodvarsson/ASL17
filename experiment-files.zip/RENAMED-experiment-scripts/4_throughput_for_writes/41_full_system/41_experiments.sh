#!/bin/bash
# chmod +x 41_experiments.sh
# ./41_experiments.sh

VC_values='1 4 8 16 24 32 40'
Worker_values='8 16 32 64'
repeat_num=3  # At least 3
exp_length=75 #(Needs to be 80s?)
sleep_length=$((exp_length + 10))

# 3 load generator VM (with 2 instances of memtier)
# 2 middlewares
# 3 memcached server
echo "========== Experiment 4.1: Throughput for Writes: Full System ==========" 

# Start and populate all three servers
echo Starting servers...
ssh server1 'screen -S memc -d -m bash -c "memcached -p 11212 -vv"'
ssh server2 'screen -S memc -d -m bash -c "memcached -p 11212 -vv"'
ssh server3 'screen -S memc -d -m bash -c "memcached -p 11212 -vv"'
echo Populating servers...
ssh server1 './memtier_benchmark-master/memtier_benchmark -d 1024 -n 10001 --key-pattern=S:S -p 11212 --ratio 1:0 --clients=1 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --hide-histogram'
ssh server2 './memtier_benchmark-master/memtier_benchmark -d 1024 -n 10001 --key-pattern=S:S -p 11212 --ratio 1:0 --clients=1 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --hide-histogram'
ssh server3 './memtier_benchmark-master/memtier_benchmark -d 1024 -n 10001 --key-pattern=S:S -p 11212 --ratio 1:0 --clients=1 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --hide-histogram'

ssh server1 'screen -S memc -d -m bash -c "memcached -p 11212 -vv"'
ssh server1 './memtier_benchmark-master/memtier_benchmark -d 1024 -n 10001 --key-pattern=S:S -p 11212 --ratio 1:0 --clients=1 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --hide-histogram'

ssh middleware1 "ping 10.0.0.5 -c 4 |& tee mw_1_pings.log"
ssh middleware1 "ping 10.0.0.7 -c 4 |& tee -a mw_1_pings.log"
ssh middleware1 "ping 10.0.0.11 -c 4 |& tee -a mw_1_pings.log"

ssh middleware2 "ping 10.0.0.5 -c 4 |& tee mw_2_pings.log"
ssh middleware2 "ping 10.0.0.7 -c 4 |& tee -a mw_2_pings.log"
ssh middleware2 "ping 10.0.0.11 -c 4 |& tee -a mw_2_pings.log"

scp middleware1:mw_1_pings.log ./logs/mw1_pings.log
scp middleware2:mw_2_pings.log ./logs/mw2_pings.log

ssh middleware1 rm mw_1_pings.log
ssh middleware2 rm mw_2_pings.log


# Iterate through experiment configurations
echo "Running Experiments..."
for wt in $Worker_values; do
	for v in $VC_values;
	do
		echo "VC=$v wt=$wt"
		# Set experiments
		for ((rep=1;rep<=repeat_num;rep++));
		do
			ssh middleware1 screen '-S mw1 -X stuff ^C'
			ssh middleware2 screen '-S mw2 -X stuff ^C'
			# Do experiment
			# Start both middlewares
			ssh middleware1 "screen -S mw1 -d -m bash -c 'java -cp ./asl-fall17-project/build/ RunMW -l 10.0.0.8 -p 6379 -t $wt -s false -m 10.0.0.5:11212 10.0.0.7:11212 10.0.0.11:11212 |& tee -a mw1_set.log'"	
			ssh middleware2 "screen -S mw2 -d -m bash -c 'java -cp ./asl-fall17-project/build/ RunMW -l 10.0.0.9 -p 6379 -t $wt -s false -m 10.0.0.5:11212 10.0.0.7:11212 10.0.0.11:11212 |& tee -a mw2_set.log'"

			# Start three load generating VMs with two instances of memtier each
			ssh client1 "screen -S client1 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 1:0 --clients=$v --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config |& tee -a client1_inst_1_set.log'"
			ssh client1 "screen -S client2 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.9 --test-time=$exp_length --ratio 1:0 --clients=$v --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config |& tee -a client1_inst_2_set.log'"
			
			ssh client2 "screen -S client1 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 1:0 --clients=$v --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config |& tee -a client2_inst_1_set.log'"
			ssh client2 "screen -S client2 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.9 --test-time=$exp_length --ratio 1:0 --clients=$v --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config |& tee -a client2_inst_2_set.log'"
			
			ssh client3 "screen -S client1 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 1:0 --clients=$v --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config |& tee -a client3_inst_1_set.log'"
			ssh client3 "screen -S client2 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.9 --test-time=$exp_length --ratio 1:0 --clients=$v --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config |& tee -a client3_inst_2_set.log'"
			
			# Wait for experiment to finish
			sleep $sleep_length

			# Kill middleware
			ssh middleware1 screen '-S mw1 -X stuff ^C'
			ssh middleware2 screen '-S mw2 -X stuff ^C'

			sleep 2

		done

		# Copy Client logs
		scp client1:client1_inst_1_set.log ./logs/wt$wt/VC_$v/SETS/client1_inst_1_set.log
		scp client1:client1_inst_2_set.log ./logs/wt$wt/VC_$v/SETS/client1_inst_2_set.log

		scp client2:client2_inst_1_set.log ./logs/wt$wt/VC_$v/SETS/client2_inst_1_set.log
		scp client2:client2_inst_2_set.log ./logs/wt$wt/VC_$v/SETS/client2_inst_2_set.log

		scp client3:client3_inst_1_set.log ./logs/wt$wt/VC_$v/SETS/client3_inst_1_set.log
		scp client3:client3_inst_2_set.log ./logs/wt$wt/VC_$v/SETS/client3_inst_2_set.log

		# Delete Client logs
		ssh client1 rm client1_inst_1_set.log
		ssh client1 rm client1_inst_2_set.log

		ssh client2 rm client2_inst_1_set.log
		ssh client2 rm client2_inst_2_set.log

		ssh client3 rm client3_inst_1_set.log
		ssh client3 rm client3_inst_2_set.log

		# Copy Middleware Logs
		scp middleware1:mw1_set.log ./logs/wt$wt/VC_$v/SETS/mw1_set.log
		scp middleware2:mw2_set.log ./logs/wt$wt/VC_$v/SETS/mw2_set.log
		scp -r middleware1:./Experiments/. ./logs/wt$wt/VC_$v/SETS/MW1/
		scp -r middleware2:./Experiments/. ./logs/wt$wt/VC_$v/SETS/MW2/
		
		# Delete Middleware logs
		ssh middleware1 rm mw1_set.log
		ssh middleware2 rm mw2_set.log	
		ssh middleware1 rm -r ./Experiments
		ssh middleware2 rm -r ./Experiments
	done
done
echo "All Experiments finished!"

# Kill server
ssh server1 screen "-S memc -X quit"
ssh server2 screen "-S memc -X quit"
ssh server3 screen "-S memc -X quit"
