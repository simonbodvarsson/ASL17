#!/bin/bash
# chmod +x 33_experiments.sh
# ./33_experiments.sh

VC_values='1 4 8 16 24 32 40'
Worker_values='8 16 32 64'
repeat_num=3  # At least 3
exp_length=75 #(Needs to be 80s?)
sleep_length=$((exp_length + 10))

# 2 load generator VM (with 2 instances of memtier)
# 1 memcached server
# 2 middlewares
echo ========== Experiment 3.3: Two Middlewares, 2 Load Generators ========== 

# Start and populate one server
echo Populating server...
ssh server1 'screen -S memc -d -m bash -c "memcached -p 11212 -vv"'
ssh server1 './memtier_benchmark-master/memtier_benchmark -d 1024 -n 10001 --key-pattern=S:S -p 11212 --ratio 1:0 --clients=1 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --hide-histogram'

ssh middleware1 "ping 10.0.0.5 -c 4 |& tee mw_1_pings.log"
ssh middleware2 "ping 10.0.0.5 -c 4 |& tee mw_2_pings.log"


scp middleware1:mw_1_pings.log ./logs/mw1_pings.log
scp middleware2:mw_2_pings.log ./logs/mw2_pings.log

ssh middleware1 rm mw_1_pings.log
ssh middleware2 rm mw_2_pings.log

# Iterate through experiment configurations
echo "Running Experiments..."
for wt in $Worker_values; do
	for v in $VC_values;
	do
		echo "VC=$v wt=$wt"
		# Get experiments
		for ((rep=1;rep<=repeat_num;rep++));
		do
			ssh middleware1 screen '-S mw1 -X stuff ^C'
			ssh middleware2 screen '-S mw2 -X stuff ^C'
			# Do experiment
			# Start first middleware
			ssh middleware1 "screen -S mw1 -d -m bash -c 'java -cp ./asl-fall17-project/build/ RunMW -l 10.0.0.8 -p 6379 -t $wt -s false -m 10.0.0.5:11212 |& tee -a mw1_get.log'"
			# Start second middleware
			ssh middleware2 "screen -S mw2 -d -m bash -c 'java -cp ./asl-fall17-project/build/ RunMW -l 10.0.0.9 -p 6379 -t $wt -s false -m 10.0.0.5:11212 |& tee -a mw2_get.log'"

			# Start first memtier instance
			ssh client1 "screen -S client1 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 0:1 --clients=$v --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config |& tee -a client1_get.log'"
			# Start second memtier instance on same machin2
			ssh client1 "screen -S client2 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.9 --test-time=$exp_length --ratio 0:1 --clients=$v --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config |& tee -a client2_get.log'"
			
			# Start second memtier instance
			ssh client2 "screen -S client1 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 0:1 --clients=$v --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config |& tee -a client1_get.log'"
			# Start second memtier instance on same machin2
			ssh client2 "screen -S client2 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.9 --test-time=$exp_length --ratio 0:1 --clients=$v --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config |& tee -a client2_get.log'"
			

			# Wait for experiment to finish
			sleep $sleep_length

			# Kill middleware
			ssh middleware1 screen '-S mw1 -X stuff ^C'
			ssh middleware2 screen '-S mw2 -X stuff ^C'

			sleep 2

		done

		# Copy logs
		scp client1:client1_get.log ./logs/wt$wt/VC_$v/GETS/client1_inst1_get.log
		scp client1:client2_get.log ./logs/wt$wt/VC_$v/GETS/client1_inst2_get.log
		scp client2:client1_get.log ./logs/wt$wt/VC_$v/GETS/client2_inst1_get.log
		scp client2:client2_get.log ./logs/wt$wt/VC_$v/GETS/client2_inst2_get.log
		scp middleware1:mw1_get.log ./logs/wt$wt/VC_$v/GETS/mw1_get.log
		scp middleware2:mw2_get.log ./logs/wt$wt/VC_$v/GETS/mw2_get.log
		
		# Delete logs
		ssh client1 rm client1_get.log
		ssh client1 rm client2_get.log
		ssh client2 rm client1_get.log
		ssh client2 rm client2_get.log
		ssh middleware1 rm mw1_get.log
		ssh middleware2 rm mw2_get.log	

		# Get middleware logs
		scp -r middleware1:./Experiments/. ./logs/wt$wt/VC_$v/GETS/MW1/
		scp -r middleware2:./Experiments/. ./logs/wt$wt/VC_$v/GETS/MW2/
		# Delete MW logs
		ssh middleware1 rm -r ./Experiments
		ssh middleware2 rm -r ./Experiments

		# Set experiments
		for ((rep=1;rep<=repeat_num;rep++));
		do
			ssh middleware1 screen '-S mw1 -X stuff ^C'
			ssh middleware2 screen '-S mw2 -X stuff ^C'
			# Do experiment
			# Start first middleware
			ssh middleware1 "screen -S mw1 -d -m bash -c 'java -cp ./asl-fall17-project/build/ RunMW -l 10.0.0.8 -p 6379 -t $wt -s false -m 10.0.0.5:11212 |& tee -a mw1_set.log'"
			# Start second middleware
			ssh middleware2 "screen -S mw2 -d -m bash -c 'java -cp ./asl-fall17-project/build/ RunMW -l 10.0.0.9 -p 6379 -t $wt -s false -m 10.0.0.5:11212 |& tee -a mw2_set.log'"

			# Start first memtier instance
			ssh client1 "screen -S client1 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 1:0 --clients=$v --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config |& tee -a client1_set.log'"
			# Start second memtier instance on same machien
			ssh client1 "screen -S client2 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.9 --test-time=$exp_length --ratio 1:0 --clients=$v --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config |& tee -a client2_set.log'"
			
			# Start second memtier instance
			ssh client2 "screen -S client1 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 1:0 --clients=$v --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config |& tee -a client1_set.log'"
			# Start second memtier instance on same machien
			ssh client2 "screen -S client2 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.9 --test-time=$exp_length --ratio 1:0 --clients=$v --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config |& tee -a client2_set.log'"
			

			# Wait for experiment to finish
			sleep $sleep_length

			# Kill middleware
			ssh middleware1 screen '-S mw1 -X stuff ^C'
			ssh middleware2 screen '-S mw2 -X stuff ^C'

			sleep 2

		done

		# Copy logs
		scp client1:client1_set.log ./logs/wt$wt/VC_$v/SETS/client1_inst1_set.log
		scp client1:client2_set.log ./logs/wt$wt/VC_$v/SETS/client1_inst2_set.log
		scp client2:client1_set.log ./logs/wt$wt/VC_$v/SETS/client2_inst1_set.log
		scp client2:client2_set.log ./logs/wt$wt/VC_$v/SETS/client2_inst2_set.log
		scp middleware1:mw1_set.log ./logs/wt$wt/VC_$v/SETS/mw1_set.log
		scp middleware2:mw2_set.log ./logs/wt$wt/VC_$v/SETS/mw2_set.log
		
		# Delete logs
		ssh client1 rm client1_set.log
		ssh client1 rm client2_set.log
		ssh client2 rm client1_set.log
		ssh client2 rm client2_set.log
		ssh middleware1 rm mw1_set.log
		ssh middleware2 rm mw2_set.log	

		# Get middleware logs
		scp -r middleware1:./Experiments/. ./logs/wt$wt/VC_$v/SETS/MW1/
		scp -r middleware2:./Experiments/. ./logs/wt$wt/VC_$v/SETS/MW2/
		# Delete MW logs
		ssh middleware1 rm -r ./Experiments
		ssh middleware2 rm -r ./Experiments
	done
done
echo "All Experiments finished!"

# Kill server
ssh server1 screen "-S memc -X quit"