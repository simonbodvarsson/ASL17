#!/bin/bash
# chmod +x 31_experiments.sh
# ./31_experiments.sh

VC_values='1 4 8 16 24 32 40'
Worker_values='8 16 32 64'
repeat_num=3  # At least 3
exp_length=75 #(Needs to be 80s?)
sleep_length=$((exp_length + 10))

# 1 load generator VM
# 1 memcached server
# 1 Middleware
echo ========== Experiment 3.1: One Middleware ========== 

# Start and populate one server
echo populating server...
ssh server1 'screen -S memc -d -m bash -c "memcached -p 11212 -vv"'
ssh server1 './memtier_benchmark-master/memtier_benchmark -d 1024 -n 10001 --key-pattern=S:S -p 11212 --ratio 1:0 --clients=1 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --hide-histogram'
sleep 5
# Iterate through experiment configurations
echo "Running Experiments..."
for wt in $Worker_values; do
	for v in $VC_values;
	do
		echo "VC=$v wt=$wt"
		for ((rep=1;rep<=repeat_num;rep++));
		do
			ssh middleware1 screen '-S mw1 -X stuff ^C'
			# Do experiment
			# Start one middleware
			ssh middleware1 "screen -S mw1 -d -m bash -c 'java -cp ./asl-fall17-project/build/ RunMW -l 10.0.0.8 -p 6379 -t $wt -s false -m 10.0.0.5:11212 |& tee -a mw1_get.log'"
			# One Client
			ssh client1 "screen -S client1 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 0:1 --clients=$v --threads=2 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config |& tee -a client1_get.log'"
			# Wait for experiment to finish
			sleep $sleep_length

			# Kill middleware
			ssh middleware1 screen '-S mw1 -X stuff ^C'

			sleep 1

		done

		# Copy logs
		scp client1:client1_get.log ./logs/wt$wt/VC_$v/GETS/client1_get.log
		scp middleware1:mw1_get.log ./logs/wt$wt/VC_$v/GETS/mw1_get.log
		# Delete logs
		ssh client1 rm client1_get.log
		ssh middleware1 rm mw1_get.log

		# Get middleware logs
		scp -r middleware1:./Experiments/. ./logs/wt$wt/VC_$v/GETS/
		# Delete MW logs
		ssh middleware1 rm -r ./Experiments


		for ((rep=1;rep<=repeat_num;rep++));
		do
			ssh middleware1 screen '-S mw1 -X stuff ^C'
			# Do experiment
			# Start one middleware
			ssh middleware1 "screen -S mw1 -d -m bash -c 'java -cp ./asl-fall17-project/build/ RunMW -l 10.0.0.8 -p 6379 -t $wt -s false -m 10.0.0.5:11212 |& tee -a mw1_set.log'"
			# One Client
			ssh client1 "screen -S client1 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --ratio 1:0 --clients=$v --threads=2 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config |& tee -a client1_set.log'"
			# Wait for experiment to finish
			sleep $sleep_length

			# Kill middleware
			ssh middleware1 screen '-S mw1 -X stuff ^C'

			sleep 1
		done

		# Copy logs
		scp client1:client1_set.log ./logs/wt$wt/VC_$v/SETS/client1_set.log
		scp middleware1:mw1_set.log ./logs/wt$wt/VC_$v/SETS/mw1_set.log
		# Delete logs
		ssh client1 rm client1_set.log
		ssh middleware1 rm mw1_set.log

		# get middleware logs
		scp -r middleware1:./Experiments/. ./logs/wt$wt/VC_$v/SETS/
		# Delete MW logs
		ssh middleware1 rm -r ./Experiments

	done
done
echo "All Experiments finished!"

# Kill server
ssh server1 screen "-S memc -X quit"