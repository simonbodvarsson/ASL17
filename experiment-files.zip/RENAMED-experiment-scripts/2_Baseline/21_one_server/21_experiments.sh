#!/bin/bash
# chmod +x 21_experiments.sh
# ./21_experiments.sh
VC_values='1 4 8 16 24 32 40'
repeat_num=3
exp_length=75 #(Needs to be 80s?)
sleep_length=$((exp_length + 10))


echo ========== Experiment 2.1: One Server ==========

# Start and populate first server
# Start memcached in a detached screen called "memc", screen -r to attach again
ssh server1 'screen -S memc -d -m bash -c "memcached -p 11212 -vv"'
echo Populating server
ssh server1 './memtier_benchmark-master/memtier_benchmark -d 1024 -n 10001 --key-pattern=S:S -p 11212 --ratio 1:0 --clients=1 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --hide-histogram'
echo "Memcached populated."


# Iterate through SET experiment configurations
echo "Running Set Experiments..."
for v in $VC_values;
do
	echo "VC=$v"
	for ((rep=1;rep<=repeat_num;rep++));
	do
		# Do experiment
		ssh client1 "screen -S client -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.5 -p 11212 --test-time=$exp_length --ratio 1:0 --clients=$v --threads=2 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --hide-histogram --show-config |& tee -a client1_set_VC_$v.log'"
		ssh client2 "screen -S client -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.5 -p 11212 --test-time=$exp_length --ratio 1:0 --clients=$v --threads=2 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --hide-histogram --show-config |& tee -a client2_set_VC_$v.log'"
		ssh client3 "screen -S client -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.5 -p 11212 --test-time=$exp_length --ratio 1:0 --clients=$v --threads=2 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --hide-histogram --show-config |& tee -a client3_set_VC_$v.log'"

		# Wait for experiment to finish
		sleep $sleep_length
	done

	# Copy logs
	scp client1:client1_set_VC_$v.log ./logs/SETS/client1_set_VC_$v.log
	scp client2:client2_set_VC_$v.log ./logs/SETS/client2_set_VC_$v.log
	scp client3:client3_set_VC_$v.log ./logs/SETS/client3_set_VC_$v.log

	# Delete logs
	ssh client1 rm client1_set_VC_$v.log
	ssh client2 rm client2_set_VC_$v.log
	ssh client3 rm client3_set_VC_$v.log
done


# Iterate through GET experiment configurations
for v in $VC_values;
do
	echo "VC=$v"
	for ((rep=1;rep<=repeat_num;rep++));
	do
		echo "Repetition=$rep"
		# Do experiment
		ssh client1 "screen -S client -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.5 -p 11212 --test-time=$exp_length --ratio 0:1 --clients=$v --threads=2 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --hide-histogram --show-config |& tee -a client1_get_VC_$v.log'"
		ssh client2 "screen -S client -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.5 -p 11212 --test-time=$exp_length --ratio 0:1 --clients=$v --threads=2 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --hide-histogram --show-config |& tee -a client2_get_VC_$v.log'"
		ssh client3 "screen -S client -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.5 -p 11212 --test-time=$exp_length --ratio 0:1 --clients=$v --threads=2 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --hide-histogram --show-config |& tee -a client3_get_VC_$v.log'"

		# Wait for experiment to finish
		sleep $sleep_length
	done

	# Copy logs
	scp client1:client1_get_VC_$v.log ./logs/GETS/client1_get_VC_$v.log
	scp client2:client2_get_VC_$v.log ./logs/GETS/client2_get_VC_$v.log
	scp client3:client3_get_VC_$v.log ./logs/GETS/client3_get_VC_$v.log

	# Delete logs
	ssh client1 rm client1_get_VC_$v.log
	ssh client2 rm client2_get_VC_$v.log
	ssh client3 rm client3_get_VC_$v.log
done
echo "Get Experiments finished!"


# Kill servers
# SSH again into first server Kill detached session with memcached running
ssh server1 screen "-S memc -X quit"
# run 3 memtier process on one machine
# cssh -a 'run_memtier_skriftan_þin.sh' vel1.azure vel1.azure vel1.azure