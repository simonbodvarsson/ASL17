#!/bin/bash
# chmod +x 21_experiments.sh
# ./21_experiments.sh
VC_values='1 4 8 16 24 32 40'
repeat_num=3  # At least 3
exp_length=75 #(Needs to be 80s?)
sleep_length=$((exp_length + 10))

echo ========== Experiment 2.2: Two Servers ========== 

# Start and populate first server
# Start memcached in a detached screen called "memc", screen -r to attach again
ssh server1 'screen -S memc -d -m bash -c "memcached -p 11212 -vv"'
ssh server2 'screen -S memc -d -m bash -c "memcached -p 11212 -vv"'

echo Populating servers
ssh server1 './memtier_benchmark-master/memtier_benchmark -d 1024 -n 10001 --key-pattern=S:S -p 11212 --ratio 1:0 --clients=1 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --hide-histogram'
ssh server2 './memtier_benchmark-master/memtier_benchmark -d 1024 -n 10001 --key-pattern=S:S -p 11212 --ratio 1:0 --clients=1 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --hide-histogram'

# Iterate through experiment configurations
echo "Running Experiments..."
for v in $VC_values;
do
	echo "VC=$v"
	echo GETS
	for ((rep=1;rep<=repeat_num;rep++));
	do
		echo "Repetition=$rep"
		# Do experiment
		ssh client1 "screen -S client1 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.5 -p 11212 --test-time=$exp_length --ratio 0:1 --clients=$v --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --hide-histogram --show-config |& tee -a client1_instance1_get_VC_$v.log'"
		ssh client1 "screen -S client2 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.7 -p 11212 --test-time=$exp_length --ratio 0:1 --clients=$v --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --hide-histogram --show-config |& tee -a client1_instance2_get_VC_$v.log'"
		# Wait for experiment to finish
		sleep $sleep_length
	done

	# Copy logs
	# scp bosimon@bosimonforaslvms1.westeurope.cloudapp.azure.com:client1_get_VC_$v.log ./logs/GETS/client1_get_VC_$v.log
	scp client1:client1_instance1_get_VC_$v.log ./logs/GETS/client1_instance1_get_VC_$v.log
	scp client1:client1_instance2_get_VC_$v.log ./logs/GETS/client1_instance2_get_VC_$v.log
	
	# Delete logs
	ssh client1 rm client1_instance1_get_VC_$v.log
	ssh client1 rm client1_instance2_get_VC_$v.log

	echo SETS
	for ((rep=1;rep<=repeat_num;rep++));
	do
		echo "Repetition=$rep"
		# Do experiment
		ssh client1 "screen -S client1 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.5 -p 11212 --test-time=$exp_length --ratio 1:0 --clients=$v --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --hide-histogram --show-config |& tee -a client1_instance1_set_VC_$v.log'"
		ssh client1 "screen -S client2 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.7 -p 11212 --test-time=$exp_length --ratio 1:0 --clients=$v --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --hide-histogram --show-config |& tee -a client1_instance2_set_VC_$v.log'"
		
		# Wait for experiment to finish
		sleep $sleep_length
	done

	# Copy logs
	#scp bosimon@bosimonforaslvms1.westeurope.cloudapp.azure.com:client1_set_VC_$v.log ./logs/SETS/client1_set_VC_$v.log
	scp client1:client1_instance1_set_VC_$v.log ./logs/SETS/client1_instance1_set_VC_$v.log
	scp client1:client1_instance2_set_VC_$v.log ./logs/SETS/client1_instance2_set_VC_$v.log
	# Delete logs
	ssh client1 rm client1_instance1_set_VC_$v.log
	ssh client1 rm client1_instance2_set_VC_$v.log
done
echo "All Experiments finished!"

ssh server1 screen "-S memc -X quit"
ssh server2 screen "-S memc -X quit"