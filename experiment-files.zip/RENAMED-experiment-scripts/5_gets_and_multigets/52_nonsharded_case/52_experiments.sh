#!/bin/bash
# chmod +x 52_experiments.sh
# ./52_experiments.sh

v=2 #VC
multikeys='1 3 6 9'
wt=64 # min(max_config, 64)
repeat_num=3  # At least 3
exp_length=75 #(Needs to be 80s?)
sleep_length=$((exp_length + 10))

# 3 load generator VM (with 2 instances of memtier)
# 2 middlewares
# 3 memcached server
# VC=2
# Max throughput config of Worker Threads for Middle-ware
echo "========== Experiment 5.2: Non-Sharded Gets and Multigets ==========" 

# Start and populate one server
echo Populating server...
ssh server1 'screen -S memc -d -m bash -c "memcached -p 11212 -vv"'
ssh server1 './memtier_benchmark-master/memtier_benchmark -d 1024 -n 10001 --key-pattern=S:S -p 11212 --ratio 1:0 --clients=1 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --hide-histogram'

ssh server2 'screen -S memc -d -m bash -c "memcached -p 11212 -vv"'
ssh server2 './memtier_benchmark-master/memtier_benchmark -d 1024 -n 10001 --key-pattern=S:S -p 11212 --ratio 1:0 --clients=1 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --hide-histogram'

ssh server3 'screen -S memc -d -m bash -c "memcached -p 11212 -vv"'
ssh server3 './memtier_benchmark-master/memtier_benchmark -d 1024 -n 10001 --key-pattern=S:S -p 11212 --ratio 1:0 --clients=1 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --hide-histogram'


ssh middleware1 "ping 10.0.0.5 -c 4 |& tee mw_1_pings.log"
ssh middleware1 "ping 10.0.0.7 -c 4 |& tee -a mw_1_pings.log"
ssh middleware1 "ping 10.0.0.11 -c 4 |& tee -a mw_1_pings.log"

ssh middleware2 "ping 10.0.0.5 -c 4 |& tee mw_2_pings.log"
ssh middleware2 "ping 10.0.0.7 -c 4 |& tee -a mw_2_pings.log"
ssh middleware2 "ping 10.0.0.11 -c 4 |& tee -a mw_2_pings.log"

scp middleware1:mw_1_pings.log ./logs/mw1_pings.log
scp middleware2:mw_2_pings.log ./logs/mw2_pings.log

ssh middleware1 rm mw_1_pings.log
ssh middleware2 rm mw_2_pings.log

# Iterate through experiment configurations
echo "Running Experiments..."
for mk in $multikeys; do
	echo "VC=$v wt=$wt mk=$mk"
	# Get experiments
	for ((rep=1;rep<=repeat_num;rep++));
	do
		ssh middleware1 screen '-S mw1 -X stuff ^C'
		ssh middleware2 screen '-S mw2 -X stuff ^C'
		# Do experiment
		# Start first middleware
		ssh middleware1 "screen -S mw1 -d -m bash -c 'java -cp ./asl-fall17-project/build/ RunMW -l 10.0.0.8 -p 6379 -t $wt -s false -m 10.0.0.5:11212 10.0.0.7:11212 10.0.0.11:11212 |& tee -a mw1_get.log'"
		# Start second middleware
		ssh middleware2 "screen -S mw2 -d -m bash -c 'java -cp ./asl-fall17-project/build/ RunMW -l 10.0.0.9 -p 6379 -t $wt -s false -m 10.0.0.5:11212 10.0.0.7:11212 10.0.0.11:11212 |& tee -a mw2_get.log'"

		# Start first memtier instance
		ssh client1 "screen -S client1 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --multi-key-get=$mk --ratio 1:$mk --clients=2 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client1_get_rep$rep.json |& tee -a client1_get.log'"
		# Start second memtier instance on same machine
		ssh client1 "screen -S client2 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.9 --test-time=$exp_length --multi-key-get=$mk --ratio 1:$mk --clients=2 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client2_get_rep$rep.json |& tee -a client2_get.log'"
		
		# Start first memtier instance
		ssh client2 "screen -S client1 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --multi-key-get=$mk --ratio 1:$mk --clients=2 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client1_get_rep$rep.json |& tee -a client1_get.log'"
		# Start second memtier instance on same machine
		ssh client2 "screen -S client2 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.9 --test-time=$exp_length --multi-key-get=$mk --ratio 1:$mk --clients=2 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client2_get_rep$rep.json |& tee -a client2_get.log'"
		
		# Start first memtier instance
		ssh client3 "screen -S client1 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.8 --test-time=$exp_length --multi-key-get=$mk --ratio 1:$mk --clients=2 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client1_get_rep$rep.json |& tee -a client1_get.log'"
		# Start second memtier instance on same machine
		ssh client3 "screen -S client2 -d -m bash -c './memtier_benchmark-master/memtier_benchmark -d 1024 -s 10.0.0.9 --test-time=$exp_length --multi-key-get=$mk --ratio 1:$mk --clients=2 --threads=1 --protocol=memcache_text --expiry-range=9999-10000 --key-maximum=10000 --show-config --json-out-file=client2_get_rep$rep.json |& tee -a client2_get.log'"
		

		# Wait for experiment to finish
		sleep $sleep_length

		# Kill middleware
		ssh middleware1 screen '-S mw1 -X stuff ^C'
		ssh middleware2 screen '-S mw2 -X stuff ^C'

		sleep 2

		scp client1:client1_get_rep$rep.json ./logs/wt$wt/mk_$mk/GETS/client1_inst1_get_rep$rep.json
		scp client1:client2_get_rep$rep.json ./logs/wt$wt/mk_$mk/GETS/client1_inst2_get_rep$rep.json
		scp client2:client1_get_rep$rep.json ./logs/wt$wt/mk_$mk/GETS/client2_inst1_get_rep$rep.json
		scp client2:client2_get_rep$rep.json ./logs/wt$wt/mk_$mk/GETS/client2_inst2_get_rep$rep.json
		scp client3:client1_get_rep$rep.json ./logs/wt$wt/mk_$mk/GETS/client3_inst1_get_rep$rep.json
		scp client3:client2_get_rep$rep.json ./logs/wt$wt/mk_$mk/GETS/client3_inst2_get_rep$rep.json

		ssh client1 rm client1_get_rep$rep.json
		ssh client1 rm client2_get_rep$rep.json

		ssh client2 rm client1_get_rep$rep.json
		ssh client2 rm client2_get_rep$rep.json

		ssh client3 rm client1_get_rep$rep.json
		ssh client3 rm client2_get_rep$rep.json
	done

	# Copy logs
	scp client1:client1_get.log ./logs/wt$wt/mk_$mk/GETS/client1_inst1_get.log
	scp client1:client2_get.log ./logs/wt$wt/mk_$mk/GETS/client1_inst2_get.log
	scp client2:client1_get.log ./logs/wt$wt/mk_$mk/GETS/client2_inst1_get.log
	scp client2:client2_get.log ./logs/wt$wt/mk_$mk/GETS/client2_inst2_get.log
	scp client3:client1_get.log ./logs/wt$wt/mk_$mk/GETS/client3_inst1_get.log
	scp client3:client2_get.log ./logs/wt$wt/mk_$mk/GETS/client3_inst2_get.log
	scp middleware1:mw1_get.log ./logs/wt$wt/mk_$mk/GETS/mw1_get.log
	scp middleware2:mw2_get.log ./logs/wt$wt/mk_$mk/GETS/mw2_get.log
	
	# Delete logs
	ssh client1 rm client1_get.log
	ssh client1 rm client2_get.log
	ssh client2 rm client1_get.log
	ssh client2 rm client2_get.log
	ssh middleware1 rm mw1_get.log
	ssh middleware2 rm mw2_get.log	

	# Get middleware logs
	scp -r middleware1:./Experiments/. ./logs/wt$wt/mk_$mk/GETS/MW1/
	scp -r middleware2:./Experiments/. ./logs/wt$wt/mk_$mk/GETS/MW2/
	# Delete MW logs
	ssh middleware1 rm -r ./Experiments
	ssh middleware2 rm -r ./Experiments

done
echo "All Experiments finished!"

# Kill server
ssh server1 screen "-S memc -X quit"
ssh server2 screen "-S memc -X quit"
ssh server3 screen "-S memc -X quit"